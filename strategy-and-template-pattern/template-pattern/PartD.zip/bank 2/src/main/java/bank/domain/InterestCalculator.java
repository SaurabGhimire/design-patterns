package bank.domain;

public interface InterestCalculator {
    double calculate(double balance);
}
