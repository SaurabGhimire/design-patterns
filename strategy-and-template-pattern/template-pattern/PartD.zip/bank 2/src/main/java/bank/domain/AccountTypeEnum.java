package bank.domain;

public enum AccountTypeEnum {
    savings,
    checkings
}
