package bank.adapter;


public class CustomerDTO {
    private String name;
    public CustomerDTO(String name){
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
