package bank.observer;

public class OnAccountChangedSubject extends Subject{
}
