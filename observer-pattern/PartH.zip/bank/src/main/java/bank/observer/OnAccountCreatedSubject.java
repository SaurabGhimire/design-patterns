package bank.observer;

public class OnAccountCreatedSubject extends Subject{

}
