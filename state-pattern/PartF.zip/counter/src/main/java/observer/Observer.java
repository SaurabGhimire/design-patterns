package observer;

public interface Observer {
    public void update(int count);
}
